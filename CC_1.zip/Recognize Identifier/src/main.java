import java.util.Scanner;

public class main {

    public static boolean isalpha(char a) {
        return (a >= 'a' && a <= 'z') || (a >= 'A' && a <= 'Z');
    }

    public static boolean isnumeric(char a) {
        return (a >= '0' && a <= '9');
    }

    public static boolean isunderscore(char a) {
        return (a == '_');
    }

    public static boolean isKeyword(String word) {
        String[] keywords = {"if", "else", "return", "etc"};
        for (String keyword : keywords) {
            if (keyword.equals(word))
                return true;
        }
        return false;
    }

    public static boolean isIdentifier(String s) {
        if (!isKeyword(s)) {
            if (isalpha(s.charAt(0)) || isunderscore(s.charAt(0))) {
                for (int i = 1; i < s.length(); i++) {
                    if (isalpha(s.charAt(i)) || isunderscore(s.charAt(i)) || isnumeric(s.charAt(i)))
                        continue;
                    return false;
                }
                return true;
            }
            return false;
        }
        return false;
    }

    public static void main(String[] args) {
        System.out.println("Enter the word: ");
        Scanner scanner = new Scanner(System.in);
        String statment = scanner.nextLine();
        System.out.println(isIdentifier(statment) ? "\nGiven string is identifier\n" : "\nnot an identifier\n");
    }
}
