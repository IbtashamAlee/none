import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.lang.*;

public class main {

    public static HashMap<String, String> firstsets = new HashMap<String, String>();
    public static HashMap<String, String> followsets = new HashMap<String, String>();

    public static void printFirstFollow(){
        for (String i : firstsets.keySet()) {
            System.out.println("key: " + i + " value: " + firstsets.get(i));
        }
//        for (String i : followsets.keySet()) {
//            System.out.println("key: " + i + " value: " + followsets.get(i));
//        }
    }

    public static String findfirst(char a ){
            return ""+a;
    }
    public static String findfollow(char a ){
        return("follow of"+a);
    }
    public static void printFromLL(LinkedList<LinkedList<String>> linkedlists){
        System.out.println("Printing CFG from Linked List\n");
        for (LinkedList<String> ll : linkedlists) {
            System.out.print(ll.get(0) + "-> ");
            for (int i=1;i<ll.size();i++){
                System.out.print(ll.get(i) + "|");
            }
            System.out.println("\b\n");
        }
    }
    public static void printProductionRules(LinkedList<LinkedList<String>> linkedlists){
        System.out.println("Printing production rules\n");
        int m=1;
        for (LinkedList<String> ll : linkedlists) {
            for (int i=1;i<ll.size();i++){
                System.out.println(m++ +"\t"+ ll.get(0) + "-> " + ll.get(i));
            }
        }
    }
//    public static void findSets(LinkedList<LinkedList<String>> linkedlists){
//        System.out.println("Finding Sets\n");
//        int m=1;
//        for (LinkedList<String> ll : linkedlists) {
//            for (int i=1;i<ll.size();i++){
//                System.out.println(m++ +"\t"+ ll.get(0) + "-> " + ll.get(i));
//                firstsets.put(ll.get(0),findfirst(ll.get(i).charAt(0)));
//            }
//        }
//    }

    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("/home/anonymous/IdeaProjects/CC/CFG2LL/src/CFG.txt");
        LinkedList<LinkedList<String>> linkedlists = new LinkedList<LinkedList<String>>();
        if (file.exists()) {                        //check if the file exists
            Scanner Reader = new Scanner(file);
            //Reading the file line by line
            while (Reader.hasNextLine()) {
                String data = Reader.nextLine().trim();
                //check if the statment is valid cfg statment and contains ->
                if (data.contains("->")) {
                    String[] parts = data.split("->");   // spliting nonterminal and production rule
                    LinkedList<String> ll = new LinkedList<String>();
                    String nonTerminal = parts[0];
                    ll.add(nonTerminal);
                    parts[1] = parts[1].replaceAll("\\s", ""); //removing spaces
                    // verifying if there are more than one production rules
                    if (parts[1].contains("|")) {
                        //spliting the production rules
                        parts = parts[1].split("\\|");
                        for (String i : parts) {
                            i = i.trim();
                            ll.add(i);
                        }
                    } else
                        ll.add(parts[1]);
                    //adding linked list to the parent linked list
                    linkedlists.add(ll);
                }
            }
            //closing the reader.
            Reader.close();
            printFromLL(linkedlists);
            printProductionRules(linkedlists);
//            findSets(linkedlists);
            printFirstFollow();
        } else
            System.out.println("file not found");
    }
}
