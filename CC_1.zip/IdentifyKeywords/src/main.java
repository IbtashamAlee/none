import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        System.out.println("Enter a word : ");
        Scanner scn  = new Scanner(System.in);
        String word = scn.nextLine();
        System.out.println(iskeyword(word)?"\nKEYWORD\n":"\nNOT KEYWORD\n");
    }

    public static boolean iskeyword(String word){
        String[] keywords = {"if","else","goto","continue","return"};
        for(String keyword:keywords){
            if(word.equals(keyword))
                return true;
        }
        return false;
    }
}
