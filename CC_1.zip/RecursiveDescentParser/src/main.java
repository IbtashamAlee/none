import java.util.Scanner;

public class main {

    public static int ip = 0;
    public static String s;

    public static void main(String[] args) {
        System.out.println("Enter the string:\n");
        Scanner scn = new Scanner(System.in);
        s = scn.nextLine();
        System.out.println("The given string is " + s);
        E();
        if (s.charAt(ip) == '$')
            System.out.println("\nThe String is accepted.");
        else
            System.out.println("\nThe String is not accepted.\n");
    }


    public static void E() {
        T();
        E1();
    }

    public static void E1() {
        if (s.charAt(ip) == '+') {
            ip++;
            T();
            E1();
        }
    }

    public static void T() {
        F();
        T1();
    }

    public static void T1() {
        if (s.charAt(ip) == '*') {
            ip++;
            F();
            T1();
        }
    }

    public static void F() {
        if (s.charAt(ip) == '(') {
            ip++;
            E();
            if (s.charAt(ip) == ')') {
                ip++;
            }
        } else if (s.charAt(ip) == 'i')
            ip++;
        else
            System.out.println("\nId expected ");
    }
}

//(i+i*i)$