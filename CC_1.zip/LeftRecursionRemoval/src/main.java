import java.util.Arrays;
import java.util.Scanner;

public class main {
    public static String[] removeRecursion(String statment){
        String[] pr = new String[2];
        Boolean containsRecursion = false;
        statment = statment.replaceAll("\\s","");
        char recurringChar=' ';
        int recurringRule = 0;
        int symbolIndex = statment.indexOf('-');
        int symbolIndex2 = statment.indexOf('>');
        if(statment.contains("->") && symbolIndex==1 && symbolIndex2==2){
            System.out.println("valid PR");
            String[] parts = statment.split("->"); //splits non-terminal and PR
            String nonTerminal = parts[0];
            String[] productionRules = parts[1].split("\\|");
            for (int i=0;i<productionRules.length;i++) {
                if((""+productionRules[i].charAt(0)).equals(nonTerminal)){
                    recurringRule = i;
                    recurringChar = productionRules[i].charAt(0);
                    containsRecursion = true;
                }
            }
            if(containsRecursion) {
                pr[0] = nonTerminal +" -> "+ productionRules[recurringRule==0?1:0] + nonTerminal +"'";
                pr[1] = nonTerminal+ "' -> " +productionRules[recurringRule].replace((""+recurringChar),"")+nonTerminal+"'|e";
            }
            else {
                pr[0] = statment;
                pr[1] = null;
            }
        }
            return pr;
    }

    public static void main(String[] args) {
        String[] pr = new String[2];
        pr = removeRecursion("E->Tt|a");
        for (String p:
             pr) {
            System.out.println(p);
        }
    }
}