import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.lang.*;

public class main {
    public static List<Set<String>> followsets = new ArrayList<Set<String>>();
    public static ArrayList<String> ProductionRules = new ArrayList<String>();
    public static List<Set<String>> firstset = new ArrayList<Set<String>>();
    public static Set<String> Terminals = new HashSet<String>();
    public static Set<String> nonTerminals = new HashSet<String>();
    public static LinkedList<LinkedList<String>> linkedlists = new LinkedList<LinkedList<String>>();

    public static void extractProductionRules() {
        for (LinkedList<String> ll : linkedlists) {
            for (int i = 1; i < ll.size(); i++) {
                ProductionRules.add(ll.get(0) + "->" + ll.get(i));
            }
        }
    }

    public static void printProductionRules() {
        System.out.println("\n Production Rules \n");
        for (String pr : ProductionRules) {
            System.out.println(pr);
        }
    }

    //This function extracts terminals and non terminals
    public static void differentiate() {
        for (String pr : ProductionRules) {
            pr = pr.trim().replaceAll("\\s", "");
            pr = pr.trim().replaceAll("->", "");
            for (int i = 0; i < pr.length(); i++) {
                if (pr.charAt(i) >= 65 && pr.charAt(i) <= 90) {
                    if(pr.charAt(i+1) == '`') {
                        nonTerminals.add("" + pr.charAt(i) + pr.charAt(i + 1));
                        i++;
                    }
                    else
                    nonTerminals.add("" + pr.charAt(i));
                } else {
                    Terminals.add("" + pr.charAt(i));
                }
            }
        }
    }

    public static void printTerminalsNonTerminals() {
        System.out.println("\nTerminals");
        for (String terminal : Terminals) {
            System.out.print(terminal + "\t");
        }
        System.out.print("\b\b");
        System.out.println("\nNon Terminals");
        for (String nonterminal : nonTerminals) {
            System.out.print(nonterminal + "\t");
        }
        System.out.print("\b\b");
    }

    public static Set<String> firstset(String nt) {
        Set<String> fs = new HashSet<String>();
        for (String pr : ProductionRules) {
            if (("" + pr.charAt(0)).equals(nt)) {
                int index = pr.indexOf('>') + 1;
                if (Terminals.contains("" + pr.charAt(index))) {
                    fs.add("" + pr.charAt(index));
                } else
                    fs.addAll(firstset("" + pr.charAt(index)));
                if (fs.contains("" + '#') && index < pr.length() - 1) {
                    fs.addAll(firstset("" + pr.charAt(index + 1)));
                }

            }
        }
        return fs;
    }

    public static void findFirst() {
        System.out.println("\n\nFirst Sets");
        for (String nonterminal : nonTerminals) {
//-            System.out.println(nonterminal);
            firstset.add(firstset(nonterminal));
        }

        System.out.println("\n" + firstset);
    }

    public static Set<String>  followSet(String nt) {
        List<String> targetList = new ArrayList<String>(nonTerminals);
        Set<String> fs = new HashSet<String>();
        for (String pr : ProductionRules) {
            if (pr.contains("" + nt)) {
                int initial_index = pr.indexOf(nt);
                if (initial_index < pr.length()-1) {
                    int index = pr.indexOf(nt) + 1;
                    if (Terminals.contains("" + pr.charAt(index))) {
                        fs.add("" + pr.charAt(index));
                    } else {
                        int nt_index = targetList.indexOf("" + pr.charAt(index));
                        fs.addAll(firstset.get(nt_index+1));

                    }
                }
            }
        }
        return fs;
    }
    public static void findFollow() {
        System.out.println("\n\nFollow Sets");
        for (String nonterminal : nonTerminals) {
            followsets.add(followSet(nonterminal));
        }
        System.out.println("\n" + followsets);
    }

    public static void cfg2ll(String filepath) throws FileNotFoundException {
        File file = new File(filepath);
        if (file.exists()) {                        //check if the file exists
            Scanner Reader = new Scanner(file);
            //Reading the file line by line
            while (Reader.hasNextLine()) {
                String data = Reader.nextLine().trim();
                //check if the statment is valid cfg statment and contains ->
                if (data.contains("->")) {
                    String[] parts = data.split("->");   // spliting nonterminal and production rule
                    LinkedList<String> ll = new LinkedList<String>();
                    String nonTerminal = parts[0];
                    ll.add(nonTerminal);
                    parts[1] = parts[1].replaceAll("\\s", ""); //removing spaces
                    // verifying if there are more than one production rules
                    if (parts[1].contains("|")) {
                        //spliting the production rules
                        parts = parts[1].split("\\|");
                        for (String i : parts) {
                            i = i.trim();
                            ll.add(i);
                        }
                    } else
                        ll.add(parts[1]);
                    //adding linked list to the parent linked list
                    linkedlists.add(ll);
                }
            }
            //closing the reader.
            Reader.close();
        } else {
            System.out.println("file not found");
        }
    }

    public static void main(String[] args) throws FileNotFoundException {
        cfg2ll("/home/anonymous/IdeaProjects/CC/LL(1)/src/CFG.txt");
        extractProductionRules();
        printProductionRules();
        differentiate();
        printTerminalsNonTerminals();


    }
}
